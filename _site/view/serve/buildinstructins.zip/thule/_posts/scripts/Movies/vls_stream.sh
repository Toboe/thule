vlc /mnt/ftp/Movies/all.m3u --http-host 192.168.1.1:8082 -I http --sout tcp://192.168.1.29
