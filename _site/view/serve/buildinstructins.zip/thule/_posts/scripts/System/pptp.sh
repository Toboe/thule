/usr/local/sbin/pptp --loglevel 0 vpn.integral-net.spb.ru vpn &
# > /dev/null 2>&1 &
