ntpdate europe.pool.ntp.org
