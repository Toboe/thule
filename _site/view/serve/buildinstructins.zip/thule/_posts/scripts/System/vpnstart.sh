/sbin/route add -host 10.37.0.254 10.32.248.1
/sbin/route add -host 217.114.0.67 10.32.248.1

pptp vpn.integral-net.spb.ru vpn &
